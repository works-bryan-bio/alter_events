<?php

class LA_Mailchimp_Neapolitan {
    public function __construct(LA_Mailchimp $master) {
        $this->master = $master;
    }

}


